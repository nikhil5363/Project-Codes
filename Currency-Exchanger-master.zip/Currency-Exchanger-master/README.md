npm i
npm start